package com.mashibing.internalcommon.responese;

import lombok.Data;

@Data
public class ForecastPriceResponse {
    private double price;
}
