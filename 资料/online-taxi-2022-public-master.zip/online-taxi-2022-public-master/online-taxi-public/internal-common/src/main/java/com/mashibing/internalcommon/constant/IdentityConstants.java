package com.mashibing.internalcommon.constant;

public class IdentityConstants {
    // 乘客身份
    public static final String PASSENGER_IDENTITY = "1";

    // 司机身份
    public static final String DRIVER_IDENTITY = "2";
}
