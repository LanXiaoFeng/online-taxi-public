package com.mashibing.internalcommon.responese;

import lombok.Data;

@Data
public class NumberCodeResponse {

    private int numberCode;
}
