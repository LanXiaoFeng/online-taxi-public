package com.mashibing.internalcommon.responese;

import lombok.Data;

@Data
public class DirectionResponse {

    private Integer distance;

    private Integer duration;
}
